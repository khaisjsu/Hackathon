# Poster AI — Frontend Prototype

A React + Vite frontend for an AI poster generation tool. The "AI" is currently mocked with a fake agent flow — perfect for showing your team and iterating on the UX before plugging in a real backend.

## Quick Start

```bash
# Install dependencies
npm install

# Start the dev server
npm run dev
```

Open http://localhost:5173 in your browser.

## What's Inside

```
src/
├── App.jsx                    # State machine: input → generating → results
├── main.jsx                   # React entry point
├── index.css                  # Tailwind + global styles
├── components/
│   ├── InputForm.jsx          # Brief input screen
│   ├── AgentProgress.jsx      # Fake agent step animations
│   ├── PosterPreview.jsx      # Renders styled poster (SVG patterns + text)
│   └── ResultsGallery.jsx     # Variants grid + PNG download
└── data/
    └── templates.js           # Poster style presets (color schemes, patterns)
```

## How the Mock "AI" Works

1. User fills the brief and clicks Generate
2. `AgentProgress` runs through 5 fake steps with staggered timing (~7s total)
3. `ResultsGallery` picks templates from `data/templates.js` matching the chosen style
4. Each poster is rendered as React + SVG, downloadable as PNG via `html-to-image`

## Plugging In Real AI Later

Replace the mock in `App.jsx`'s `handleGenerate` with a real API call. The `brief` object you pass to `ResultsGallery` just needs:

- `prompt`, `headline`, `subtext`
- `style`, `purpose`, `size`
- (Add) `templates`: an array of generated poster configs

Then update `ResultsGallery` to use `brief.templates` instead of importing from `data/templates.js`.

## Stack

- **React 18** + **Vite** — fast dev server
- **Tailwind CSS** — styling
- **Framer Motion** — animations
- **Lucide React** — icons
- **html-to-image** — export posters as PNG

## Customizing

- **Add new styles** → edit `src/data/templates.js`, add a new key with template variants
- **Change agent steps** → edit the `steps` array in `AgentProgress.jsx`
- **Tweak the look** → all colors and gradients are in `index.css` and Tailwind classes
