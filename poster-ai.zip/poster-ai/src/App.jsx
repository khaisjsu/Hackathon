import { useState } from 'react';
import { AnimatePresence } from 'framer-motion';
import InputForm from './components/InputForm';
import AgentProgress from './components/AgentProgress';
import ResultsGallery from './components/ResultsGallery';

export default function App() {
  const [stage, setStage] = useState('input'); // 'input' | 'generating' | 'results'
  const [brief, setBrief] = useState(null);

  const handleGenerate = (data) => {
    setBrief(data);
    setStage('generating');
  };

  const handleComplete = () => {
    setStage('results');
  };

  const handleRegenerate = () => {
    setStage('generating');
  };

  const handleReset = () => {
    setStage('input');
    setBrief(null);
  };

  return (
    <div className="min-h-screen">
      {/* Top nav */}
      <nav className="fixed top-0 left-0 right-0 z-50 backdrop-blur-xl bg-zinc-950/50 border-b border-white/5">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-pink-500 flex items-center justify-center font-bold">
              P
            </div>
            <span className="font-display font-bold text-lg">Poster AI</span>
          </div>
          <div className="text-xs text-zinc-500">v0.1 · Frontend Preview</div>
        </div>
      </nav>

      <main className="pt-16">
        <AnimatePresence mode="wait">
          {stage === 'input' && (
            <InputForm key="input" onGenerate={handleGenerate} />
          )}
          {stage === 'generating' && brief && (
            <AgentProgress key="gen" brief={brief} onComplete={handleComplete} />
          )}
          {stage === 'results' && brief && (
            <ResultsGallery
              key="results"
              brief={brief}
              onRegenerate={handleRegenerate}
              onReset={handleReset}
            />
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
