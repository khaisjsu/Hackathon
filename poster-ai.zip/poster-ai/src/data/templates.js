// Sample poster templates that the "AI" picks from based on style
// In production, these would be generated dynamically by the agent

export const posterTemplates = {
  bold: [
    {
      id: 'bold-1',
      bg: 'linear-gradient(135deg, #ff0080 0%, #ff8c00 100%)',
      accent: '#fff200',
      textColor: '#ffffff',
      pattern: 'circles',
    },
    {
      id: 'bold-2',
      bg: 'linear-gradient(135deg, #4f46e5 0%, #ec4899 50%, #f59e0b 100%)',
      accent: '#ffffff',
      textColor: '#ffffff',
      pattern: 'lines',
    },
    {
      id: 'bold-3',
      bg: 'linear-gradient(135deg, #dc2626 0%, #7c2d12 100%)',
      accent: '#fbbf24',
      textColor: '#ffffff',
      pattern: 'grid',
    },
  ],
  minimal: [
    {
      id: 'minimal-1',
      bg: '#fafafa',
      accent: '#000000',
      textColor: '#0a0a0a',
      pattern: 'none',
    },
    {
      id: 'minimal-2',
      bg: '#0a0a0a',
      accent: '#ffffff',
      textColor: '#ffffff',
      pattern: 'none',
    },
    {
      id: 'minimal-3',
      bg: '#f5f5f4',
      accent: '#dc2626',
      textColor: '#1c1917',
      pattern: 'dot',
    },
  ],
  playful: [
    {
      id: 'playful-1',
      bg: 'linear-gradient(135deg, #fde68a 0%, #fbbf24 50%, #f472b6 100%)',
      accent: '#7c3aed',
      textColor: '#1e1b4b',
      pattern: 'circles',
    },
    {
      id: 'playful-2',
      bg: 'linear-gradient(135deg, #a7f3d0 0%, #67e8f9 100%)',
      accent: '#db2777',
      textColor: '#0f172a',
      pattern: 'wave',
    },
    {
      id: 'playful-3',
      bg: 'linear-gradient(135deg, #fbcfe8 0%, #ddd6fe 100%)',
      accent: '#f59e0b',
      textColor: '#581c87',
      pattern: 'dot',
    },
  ],
  corporate: [
    {
      id: 'corp-1',
      bg: 'linear-gradient(135deg, #1e3a8a 0%, #1e40af 100%)',
      accent: '#60a5fa',
      textColor: '#ffffff',
      pattern: 'lines',
    },
    {
      id: 'corp-2',
      bg: '#ffffff',
      accent: '#0f172a',
      textColor: '#0f172a',
      pattern: 'none',
    },
    {
      id: 'corp-3',
      bg: 'linear-gradient(135deg, #0f172a 0%, #1e293b 100%)',
      accent: '#22d3ee',
      textColor: '#ffffff',
      pattern: 'grid',
    },
  ],
  retro: [
    {
      id: 'retro-1',
      bg: 'linear-gradient(135deg, #fb923c 0%, #f43f5e 50%, #8b5cf6 100%)',
      accent: '#fde047',
      textColor: '#ffffff',
      pattern: 'sun',
    },
    {
      id: 'retro-2',
      bg: 'linear-gradient(180deg, #1e1b4b 0%, #831843 100%)',
      accent: '#f472b6',
      textColor: '#fde047',
      pattern: 'sun',
    },
    {
      id: 'retro-3',
      bg: '#fef3c7',
      accent: '#b45309',
      textColor: '#7c2d12',
      pattern: 'wave',
    },
  ],
};

export const sizeOptions = [
  { id: 'a4', label: 'A4 Portrait', ratio: '210/297', w: 420, h: 594 },
  { id: 'square', label: 'Square 1:1', ratio: '1/1', w: 500, h: 500 },
  { id: 'story', label: 'Story 9:16', ratio: '9/16', w: 360, h: 640 },
  { id: 'landscape', label: 'Landscape 16:9', ratio: '16/9', w: 640, h: 360 },
];

export const stylePresets = [
  { id: 'bold', label: '🔥 Bold' },
  { id: 'minimal', label: '◻️ Minimal' },
  { id: 'playful', label: '🎉 Playful' },
  { id: 'corporate', label: '💼 Corporate' },
  { id: 'retro', label: '🌅 Retro' },
];

export const purposeOptions = [
  { id: 'event', label: 'Event' },
  { id: 'marketing', label: 'Marketing' },
  { id: 'social', label: 'Social Media' },
  { id: 'announcement', label: 'Announcement' },
];
