import { useState } from 'react';
import { Sparkles, Wand2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { stylePresets, purposeOptions, sizeOptions } from '../data/templates';

export default function InputForm({ onGenerate }) {
  const [prompt, setPrompt] = useState('');
  const [headline, setHeadline] = useState('');
  const [subtext, setSubtext] = useState('');
  const [style, setStyle] = useState('bold');
  const [purpose, setPurpose] = useState('event');
  const [size, setSize] = useState('a4');

  const handleSubmit = () => {
    if (!prompt.trim() || !headline.trim()) return;
    onGenerate({ prompt, headline, subtext, style, purpose, size });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="max-w-3xl mx-auto px-6 py-12"
    >
      {/* Hero */}
      <div className="text-center mb-12">
        <motion.div
          animate={{ rotate: [0, 10, -10, 0] }}
          transition={{ duration: 2, repeat: Infinity, repeatDelay: 3 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-6"
        >
          <Sparkles className="w-4 h-4 text-yellow-400" />
          <span className="text-sm text-zinc-300">AI-powered poster generation</span>
        </motion.div>
        <h1 className="font-display text-5xl md:text-6xl font-bold mb-4 bg-gradient-to-r from-white via-indigo-200 to-pink-200 bg-clip-text text-transparent">
          Design posters with AI
        </h1>
        <p className="text-zinc-400 text-lg">
          Describe what you need. Our agent will design it for you.
        </p>
      </div>

      {/* Form */}
      <div className="glass rounded-3xl p-8 space-y-6">
        {/* Prompt */}
        <div>
          <label className="block text-sm font-medium text-zinc-300 mb-2">
            Describe your poster
          </label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Summer music festival at Golden Gate Park, vibrant and energetic, targeting young adults..."
            rows={3}
            className="w-full"
          />
        </div>

        {/* Text fields */}
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-zinc-300 mb-2">
              Headline
            </label>
            <input
              type="text"
              value={headline}
              onChange={(e) => setHeadline(e.target.value)}
              placeholder="SUMMER FEST"
              className="w-full"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-zinc-300 mb-2">
              Subtext (optional)
            </label>
            <input
              type="text"
              value={subtext}
              onChange={(e) => setSubtext(e.target.value)}
              placeholder="July 15 · Golden Gate Park"
              className="w-full"
            />
          </div>
        </div>

        {/* Purpose */}
        <div>
          <label className="block text-sm font-medium text-zinc-300 mb-3">Purpose</label>
          <div className="flex flex-wrap gap-2">
            {purposeOptions.map((p) => (
              <button
                key={p.id}
                onClick={() => setPurpose(p.id)}
                className={`chip ${purpose === p.id ? 'chip-active' : 'chip-default'}`}
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>

        {/* Style */}
        <div>
          <label className="block text-sm font-medium text-zinc-300 mb-3">Style</label>
          <div className="flex flex-wrap gap-2">
            {stylePresets.map((s) => (
              <button
                key={s.id}
                onClick={() => setStyle(s.id)}
                className={`chip ${style === s.id ? 'chip-active' : 'chip-default'}`}
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>

        {/* Size */}
        <div>
          <label className="block text-sm font-medium text-zinc-300 mb-3">Size</label>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            {sizeOptions.map((s) => (
              <button
                key={s.id}
                onClick={() => setSize(s.id)}
                className={`p-3 rounded-xl border text-sm transition-all ${
                  size === s.id
                    ? 'border-indigo-500 bg-indigo-500/20 text-white'
                    : 'border-white/10 bg-white/5 hover:bg-white/10 text-zinc-300'
                }`}
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>

        {/* Submit */}
        <button
          onClick={handleSubmit}
          disabled={!prompt.trim() || !headline.trim()}
          className="btn-primary w-full flex items-center justify-center gap-2 text-lg"
        >
          <Wand2 className="w-5 h-5" />
          Generate Posters
        </button>

        <p className="text-xs text-zinc-500 text-center">
          Tip: Press <kbd className="px-1.5 py-0.5 bg-white/10 rounded">Cmd</kbd>+
          <kbd className="px-1.5 py-0.5 bg-white/10 rounded">Enter</kbd> to generate
        </p>
      </div>
    </motion.div>
  );
}
