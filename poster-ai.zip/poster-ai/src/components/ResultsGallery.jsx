import { useRef } from 'react';
import { motion } from 'framer-motion';
import { Download, RefreshCw, ArrowLeft } from 'lucide-react';
import { toPng } from 'html-to-image';
import PosterPreview from './PosterPreview';
import { posterTemplates, sizeOptions } from '../data/templates';

export default function ResultsGallery({ brief, onRegenerate, onReset }) {
  const templates = posterTemplates[brief.style] || posterTemplates.bold;
  const size = sizeOptions.find((s) => s.id === brief.size) || sizeOptions[0];
  const refs = useRef([]);

  const handleDownload = async (idx) => {
    const node = refs.current[idx];
    if (!node) return;
    try {
      const dataUrl = await toPng(node, { pixelRatio: 2, cacheBust: true });
      const link = document.createElement('a');
      link.download = `poster-${brief.style}-${idx + 1}.png`;
      link.href = dataUrl;
      link.click();
    } catch (err) {
      console.error('Download failed:', err);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="max-w-7xl mx-auto px-6 py-12"
    >
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-10">
        <div>
          <button
            onClick={onReset}
            className="flex items-center gap-2 text-zinc-400 hover:text-white mb-3 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Start over
          </button>
          <h2 className="font-display text-4xl font-bold mb-1">
            Your posters are ready
          </h2>
          <p className="text-zinc-400">
            {templates.length} variants generated · Click any to download
          </p>
        </div>
        <button
          onClick={onRegenerate}
          className="btn-ghost flex items-center gap-2"
        >
          <RefreshCw className="w-4 h-4" />
          Regenerate all
        </button>
      </div>

      {/* Gallery */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {templates.map((template, idx) => (
          <motion.div
            key={template.id}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.15, duration: 0.5 }}
            className="group"
          >
            <div className="glass rounded-2xl p-4 hover:border-white/20 transition-all">
              <div className="mb-4">
                <PosterPreview
                  ref={(el) => (refs.current[idx] = el)}
                  template={template}
                  brief={brief}
                  size={size}
                />
              </div>
              <div className="flex items-center justify-between gap-2">
                <span className="text-sm text-zinc-400">Variant {idx + 1}</span>
                <button
                  onClick={() => handleDownload(idx)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-indigo-500/20 hover:text-indigo-200 border border-white/10 hover:border-indigo-500/50 text-sm font-medium transition-all"
                >
                  <Download className="w-3.5 h-3.5" />
                  Download PNG
                </button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Brief summary */}
      <div className="mt-12 glass rounded-2xl p-6">
        <h3 className="text-sm font-semibold text-zinc-400 uppercase tracking-wider mb-3">
          Brief
        </h3>
        <p className="text-zinc-200 mb-3">{brief.prompt}</p>
        <div className="flex flex-wrap gap-2 text-xs">
          <span className="px-2 py-1 rounded-md bg-white/5 text-zinc-300">
            Style: {brief.style}
          </span>
          <span className="px-2 py-1 rounded-md bg-white/5 text-zinc-300">
            Purpose: {brief.purpose}
          </span>
          <span className="px-2 py-1 rounded-md bg-white/5 text-zinc-300">
            Size: {size.label}
          </span>
        </div>
      </div>
    </motion.div>
  );
}
