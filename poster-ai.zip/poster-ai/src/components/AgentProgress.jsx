import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Check, Loader2, Circle, Sparkles } from 'lucide-react';

const steps = [
  { id: 1, label: 'Understanding your brief', detail: 'Parsing intent, audience, and tone…' },
  { id: 2, label: 'Choosing color palette', detail: 'Selecting harmonious colors for your style…' },
  { id: 3, label: 'Generating background visuals', detail: 'Creating unique background compositions…' },
  { id: 4, label: 'Composing layout', detail: 'Placing typography and visual elements…' },
  { id: 5, label: 'Reviewing quality', detail: 'Self-critique pass for legibility and balance…' },
];

export default function AgentProgress({ brief, onComplete }) {
  const [currentStep, setCurrentStep] = useState(0);

  useEffect(() => {
    if (currentStep >= steps.length) {
      const timer = setTimeout(() => onComplete(), 600);
      return () => clearTimeout(timer);
    }
    const timer = setTimeout(() => {
      setCurrentStep((s) => s + 1);
    }, 1400 + Math.random() * 600);
    return () => clearTimeout(timer);
  }, [currentStep, onComplete]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="max-w-2xl mx-auto px-6 py-16"
    >
      <div className="text-center mb-10">
        <motion.div
          animate={{ scale: [1, 1.1, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-500 to-pink-500 mb-4 shadow-2xl shadow-indigo-500/30"
        >
          <Sparkles className="w-8 h-8 text-white" />
        </motion.div>
        <h2 className="font-display text-3xl font-bold mb-2">Agent at work…</h2>
        <p className="text-zinc-400">
          Designing posters for: <span className="text-zinc-200">"{brief.headline}"</span>
        </p>
      </div>

      <div className="glass rounded-2xl p-6 space-y-3">
        {steps.map((step, idx) => {
          const isDone = idx < currentStep;
          const isActive = idx === currentStep;
          const isPending = idx > currentStep;

          return (
            <motion.div
              key={step.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: idx * 0.1 }}
              className={`flex items-start gap-4 p-3 rounded-xl transition-all ${
                isActive ? 'bg-white/5' : ''
              }`}
            >
              <div className="mt-0.5 flex-shrink-0">
                {isDone && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="w-6 h-6 rounded-full bg-green-500/20 border border-green-500 flex items-center justify-center"
                  >
                    <Check className="w-3.5 h-3.5 text-green-400" />
                  </motion.div>
                )}
                {isActive && (
                  <div className="w-6 h-6 rounded-full bg-indigo-500/20 border border-indigo-500 flex items-center justify-center">
                    <Loader2 className="w-3.5 h-3.5 text-indigo-400 animate-spin" />
                  </div>
                )}
                {isPending && (
                  <div className="w-6 h-6 rounded-full bg-white/5 border border-white/10 flex items-center justify-center">
                    <Circle className="w-3 h-3 text-zinc-600" />
                  </div>
                )}
              </div>
              <div className="flex-1">
                <p
                  className={`font-medium ${
                    isPending ? 'text-zinc-500' : 'text-zinc-100'
                  }`}
                >
                  {step.label}
                </p>
                <AnimatePresence>
                  {isActive && (
                    <motion.p
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="text-sm text-zinc-400 mt-1"
                    >
                      {step.detail}
                    </motion.p>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>
          );
        })}
      </div>
    </motion.div>
  );
}
