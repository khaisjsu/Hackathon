import { forwardRef } from 'react';

// Decorative SVG patterns
const Pattern = ({ type, color }) => {
  if (type === 'circles') {
    return (
      <svg className="absolute inset-0 w-full h-full opacity-30" preserveAspectRatio="none">
        <circle cx="15%" cy="20%" r="60" fill={color} opacity="0.5" />
        <circle cx="85%" cy="80%" r="100" fill={color} opacity="0.4" />
        <circle cx="80%" cy="15%" r="40" fill={color} opacity="0.6" />
      </svg>
    );
  }
  if (type === 'lines') {
    return (
      <svg className="absolute inset-0 w-full h-full opacity-20" preserveAspectRatio="none">
        {[...Array(8)].map((_, i) => (
          <line
            key={i}
            x1="0"
            y1={`${i * 15}%`}
            x2="100%"
            y2={`${i * 15 + 30}%`}
            stroke={color}
            strokeWidth="2"
          />
        ))}
      </svg>
    );
  }
  if (type === 'grid') {
    return (
      <svg className="absolute inset-0 w-full h-full opacity-15" preserveAspectRatio="none">
        <defs>
          <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M 40 0 L 0 0 0 40" fill="none" stroke={color} strokeWidth="1" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#grid)" />
      </svg>
    );
  }
  if (type === 'dot') {
    return (
      <svg className="absolute inset-0 w-full h-full opacity-25" preserveAspectRatio="none">
        <defs>
          <pattern id="dots" width="20" height="20" patternUnits="userSpaceOnUse">
            <circle cx="2" cy="2" r="1.5" fill={color} />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#dots)" />
      </svg>
    );
  }
  if (type === 'wave') {
    return (
      <svg className="absolute bottom-0 left-0 w-full opacity-30" viewBox="0 0 200 50" preserveAspectRatio="none">
        <path
          d="M0,25 Q50,5 100,25 T200,25 L200,50 L0,50 Z"
          fill={color}
        />
      </svg>
    );
  }
  if (type === 'sun') {
    return (
      <svg className="absolute top-0 right-0 w-1/2 h-1/2 opacity-40" viewBox="0 0 100 100">
        <circle cx="100" cy="0" r="60" fill={color} />
        {[...Array(8)].map((_, i) => (
          <line
            key={i}
            x1="100"
            y1="0"
            x2={100 - 80 * Math.cos((i * Math.PI) / 8)}
            y2={80 * Math.sin((i * Math.PI) / 8)}
            stroke={color}
            strokeWidth="2"
            opacity="0.5"
          />
        ))}
      </svg>
    );
  }
  return null;
};

const PosterPreview = forwardRef(({ template, brief, size }, ref) => {
  const isLandscape = size.id === 'landscape';
  const isStory = size.id === 'story';

  return (
    <div
      ref={ref}
      className="relative overflow-hidden rounded-xl shadow-2xl"
      style={{
        background: template.bg,
        aspectRatio: size.ratio,
        width: '100%',
      }}
    >
      <Pattern type={template.pattern} color={template.accent} />

      {/* Top accent bar */}
      <div
        className="absolute top-4 left-4 right-4 h-1 rounded-full"
        style={{ background: template.accent, opacity: 0.6 }}
      />

      {/* Content */}
      <div
        className={`relative h-full flex flex-col p-6 md:p-8 ${
          isLandscape ? 'justify-center items-start' : 'justify-end'
        }`}
      >
        {/* Tag */}
        <div
          className="inline-block self-start px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider mb-3"
          style={{
            background: template.accent,
            color: template.bg.includes('gradient') ? '#000' : template.textColor,
          }}
        >
          {brief.purpose}
        </div>

        {/* Headline */}
        <h1
          className="font-display font-bold leading-none tracking-tight"
          style={{
            color: template.textColor,
            fontSize: isStory ? '2.5rem' : isLandscape ? '2rem' : '3rem',
            lineHeight: 0.9,
          }}
        >
          {brief.headline.toUpperCase()}
        </h1>

        {/* Subtext */}
        {brief.subtext && (
          <p
            className="mt-3 font-medium"
            style={{
              color: template.textColor,
              opacity: 0.85,
              fontSize: isLandscape ? '0.875rem' : '1rem',
            }}
          >
            {brief.subtext}
          </p>
        )}

        {/* Bottom decoration */}
        <div className="mt-4 flex items-center gap-2">
          <div
            className="h-0.5 w-8 rounded-full"
            style={{ background: template.accent }}
          />
          <span
            className="text-xs font-medium uppercase tracking-widest"
            style={{ color: template.textColor, opacity: 0.7 }}
          >
            {new Date().getFullYear()}
          </span>
        </div>
      </div>
    </div>
  );
});

PosterPreview.displayName = 'PosterPreview';
export default PosterPreview;
